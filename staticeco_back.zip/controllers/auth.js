const mySqlDatabase = require('../connections-database');


module.exports.login = (req, res) => {
    console.log(req.body)

    mySqlDatabase.query("CALL `sp_report`(2019,1,0,null,1,0)", (err, rows, fields) => {
        console.log(err)
        console.log(rows)
        console.log(fields)
        res.json({err, rows, fields});
    })
    //
    // mySqlDatabase.query('SELECT * FROM subjects', (err, rows, fields) => {
    //     console.log(rows)
    // })

};

