module.exports = {
    mySql: {
        host: "192.168.1.109",
        user: "ron",
        password: "-ron*",
        database: "ecoportal",
        multipleStatements: true
    }
};
